// Tiny educational language: lexer -> parser/AST -> semantic checks -> interpreter.
const sample=`// Sample program
let x = 10;
let y = 5;
let total = x + y * 2;
print("Total:");
print(total);
if (total > 15) {
  print("Greater than 15");
} else {
  print("15 or less");
}
let count = 3;
while (count > 0) {
  print(count);
  count = count - 1;
}`;
class LangError extends Error{constructor(m,l){super((l?"Line "+l+": ":"")+m)}}
class Lexer{
 constructor(s){this.s=s;this.i=0;this.line=1;this.out=[]}
 peek(n=0){return this.s[this.i+n]||""}
 take(){let c=this.s[this.i++];if(c==="\\n")this.line++;return c}
 add(type,value,line=this.line){this.out.push({type,value,line})}
 scan(){while(this.i<this.s.length){let c=this.peek();if(/\\s/.test(c)){this.take();continue}
 if(c==="/"&&this.peek(1)==="/"){while(this.i<this.s.length&&this.take()!=="\\n"){}continue}
 let line=this.line;
 if(/[A-Za-z_]/.test(c)){let v="";while(/[A-Za-z0-9_]/.test(this.peek()))v+=this.take();this.add(["let","print","if","else","while","true","false"].includes(v)?"KEYWORD":"IDENTIFIER",v,line);continue}
 if(/[0-9]/.test(c)){let v="";while(/[0-9]/.test(this.peek()))v+=this.take();if(this.peek()==="."){v+=this.take();while(/[0-9]/.test(this.peek()))v+=this.take()}this.add("NUMBER",Number(v),line);continue}
 if(c==='"'||c==="'"){let q=this.take(),v="";while(this.i<this.s.length&&this.peek()!==q){if(this.peek()==="\\\\"){this.take();let e=this.take();v+=e==="n"?"\\n":e}else v+=this.take()}if(this.i>=this.s.length)throw new LangError("Unterminated string",line);this.take();this.add("STRING",v,line);continue}
 let two=c+this.peek(1);if(["==","!=","<=",">="].includes(two)){this.take();this.take();this.add("OPERATOR",two,line);continue}
 if("+-*/%<>=".includes(c)){this.take();this.add("OPERATOR",c,line);continue}
 if("(){};".includes(c)){this.take();this.add("PUNCTUATION",c,line);continue}
 throw new LangError("Unexpected character "+c,line)}
 this.add("EOF","EOF");return this.out}
}
class Parser{
 constructor(t){this.t=t;this.i=0} p(){return this.t[this.i]} check(v){return this.p().value===v} match(...v){if(v.includes(this.p().value)){this.i++;return true}return false}
 need(v,msg){if(!this.check(v))throw new LangError(msg||"Expected "+v,this.p().line);return this.t[this.i++]}
 ident(){if(this.p().type!=="IDENTIFIER")throw new LangError("Expected variable name",this.p().line);return this.t[this.i++].value}
 parse(){let body=[];while(!this.check("EOF"))body.push(this.stmt());return{type:"Program",body}}
 stmt(){if(this.match("let")){let name=this.ident();this.need("=");let value=this.expr();this.need(";","Expected ;");return{type:"Declare",name,value}}
 if(this.match("print")){this.need("(");let value=this.expr();this.need(")");this.need(";");return{type:"Print",value}}
 if(this.match("if")){this.need("(");let condition=this.expr();this.need(")");let yes=this.block(),no=[];if(this.match("else"))no=this.block();return{type:"If",condition,yes,no}}
 if(this.match("while")){this.need("(");let condition=this.expr();this.need(")");return{type:"While",condition,body:this.block()}}
 if(this.p().type==="IDENTIFIER"){let name=this.ident();this.need("=");let value=this.expr();this.need(";");return{type:"Assign",name,value}}
 throw new LangError("Unexpected token "+this.p().value,this.p().line)}
 block(){this.need("{");let b=[];while(!this.check("}")&&!this.check("EOF"))b.push(this.stmt());this.need("}");return b}
 expr(){return this.equality()} equality(){let a=this.compare();while(this.match("==","!=")){let op=this.t[this.i-1].value;a={type:"Binary",op,left:a,right:this.compare()}}return a}
 compare(){let a=this.term();while(this.match(">","<",">=","<=")){let op=this.t[this.i-1].value;a={type:"Binary",op,left:a,right:this.term()}}return a}
 term(){let a=this.factor();while(this.match("+","-")){let op=this.t[this.i-1].value;a={type:"Binary",op,left:a,right:this.factor()}}return a}
 factor(){let a=this.unary();while(this.match("*","/","%")){let op=this.t[this.i-1].value;a={type:"Binary",op,left:a,right:this.unary()}}return a}
 unary(){if(this.match("-"))return{type:"Unary",right:this.unary()};return this.primary()}
 primary(){if(this.match("true"))return{type:"Literal",value:true};if(this.match("false"))return{type:"Literal",value:false};if(["NUMBER","STRING"].includes(this.p().type))return{type:"Literal",value:this.t[this.i++].value};if(this.p().type==="IDENTIFIER")return{type:"Variable",name:this.t[this.i++].value};if(this.match("(")){let e=this.expr();this.need(")");return e}throw new LangError("Expected expression",this.p().line)}
}
class Interpreter{
 constructor(){this.env=new Map;this.out=[];this.steps=0}
 tick(){if(++this.steps>10000)throw new LangError("Maximum execution steps exceeded (possible infinite loop)")}
 run(ast){ast.body.forEach(s=>this.exec(s));return this.out.join("\\n")}
 exec(s){this.tick();if(s.type==="Declare"){if(this.env.has(s.name))throw new LangError("Variable already declared: "+s.name);this.env.set(s.name,this.eval(s.value))}
 else if(s.type==="Assign"){if(!this.env.has(s.name))throw new LangError("Undeclared variable: "+s.name);this.env.set(s.name,this.eval(s.value))}
 else if(s.type==="Print")this.out.push(String(this.eval(s.value)));
 else if(s.type==="If")(this.eval(s.condition)?s.yes:s.no).forEach(x=>this.exec(x));
 else if(s.type==="While"){while(this.eval(s.condition)){this.tick();s.body.forEach(x=>this.exec(x))}}}
 eval(e){if(e.type==="Literal")return e.value;if(e.type==="Variable"){if(!this.env.has(e.name))throw new LangError("Undeclared variable: "+e.name);return this.env.get(e.name)}
 if(e.type==="Unary")return -Number(this.eval(e.right));
 if(e.type==="Binary"){let a=this.eval(e.left),b=this.eval(e.right);switch(e.op){case "+":return typeof a==="string"||typeof b==="string"?String(a)+String(b):Number(a)+Number(b);case "-":return Number(a)-Number(b);case "*":return Number(a)*Number(b);case "/":if(Number(b)===0)throw new LangError("Division by zero");return Number(a)/Number(b);case "%":if(Number(b)===0)throw new LangError("Division by zero");return Number(a)%Number(b);case ">":return a>b;case "<":return a<b;case ">=":return a>=b;case "<=":return a<=b;case "==":return a===b;case "!=":return a!==b}}}
}
const $=id=>document.getElementById(id);$("code").value=sample;$("sample").onclick=()=>$("code").value=sample;
$("run").onclick=()=>{try{let tokens=new Lexer($("code").value).scan();$("tokens").innerHTML=tokens.filter(x=>x.type!=="EOF").map(x=>`<tr><td>${x.type}</td><td>${String(x.value).replaceAll("&","&amp;").replaceAll("<","&lt;")}</td><td>${x.line}</td></tr>`).join("");let ast=new Parser(tokens).parse();$("ast").textContent=JSON.stringify(ast,null,2);let vm=new Interpreter();let result=vm.run(ast);$("output").textContent=result||"Program completed with no output."; }catch(e){$("output").textContent=e.message;$("ast").textContent="Parsing/execution stopped."}};
