# Design Your Own Programming

B.Tech Compiler Design Project — browser-based custom language interpreter.

## Team
- Rahul Modak — BWU/BTS/24/182
- Aritra Gole — BWU/BTS/24/195
- Souvik Ghosh — BWU/BTS/24/213

## Run
Download the repository and open `index.html` in Chrome, Edge, Firefox, or another modern browser. No installation is needed. Click **Run** to execute the sample.

## Language features
- `let` variable declarations and assignments
- Numeric, string, and Boolean literals
- Arithmetic operators `+ - * / %`
- Comparison operators `> < >= <= == !=`
- `print(expression);`
- `if (...) { ... } else { ... }`
- `while (...) { ... }`
- Single-line comments beginning with `//`
- Token listing, AST output, and basic semantic error checks

## Example
```text
let n = 4;
while (n > 0) {
  print(n);
  n = n - 1;
}
```

## Processing pipeline
Source code → Lexer → Parser → AST → Semantic checks during execution → Interpreter → Output.

## Files
- `index.html`: user interface
- `style.css`: styling
- `app.js`: lexer, parser, AST construction, and interpreter

## Limitations
This is an educational interpreter, not a production compiler. It uses a simple global variable environment. Functions, arrays, static type checking, intermediate-code generation, and machine-code generation are not implemented.
